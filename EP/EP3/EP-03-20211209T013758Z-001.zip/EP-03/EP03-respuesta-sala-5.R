if(!require(dplyr)){
  install.packages("dplyr", dependencies=TRUE)
  require(dplyr)
}
if(!require(ggpubr)){
  install.packages("ggpubr", dependencies=TRUE)
  require(ggpubr)
}
if(!require(sjPlot)){
  install.packages("sjPlot", dependencies=TRUE)
  require(sjPlot)
}


basename <- "EP-03 Datos Casen 2017.csv"
file <- file.path("./", basename)
poblacion <- read.csv(file = file)
tama�o <- nrow(poblacion)
ingreso <- as.numeric(poblacion[["ytot"]])
poda <- 0.2
q20 <- quantile(ingreso, poda)
q80 <- quantile(ingreso, 1 - poda)
ingreso.podado <- ingreso[ingreso > q20 & ingreso < q80]
tama�o.podado <- length(ingreso.podado)
media.ingreso <- mean(ingreso.podado)
sd.ingreso <- sqrt (sum((ingreso.podado - media.ingreso)^2) / tama�o.podado )
set.seed(2001)
ingreso.normal <- rnorm(5000, mean = media.ingreso, sd = sd.ingreso)


z <- (ingreso.normal - media.ingreso)/sd.ingreso


libertad_seis <- sample(z,6)
libertad_doce <- sample(z,12)

libertad_seis <- libertad_seis^2
libertad_doce <- libertad_doce^2

chi_Cuadrado_seis <-sum(libertad_seis)
chi_Cuadrado_doce <-sum(libertad_doce)

f<- (chi_Cuadrado_seis/6)/(chi_Cuadrado_doce/12) 


set.seed(2001)
n.repeticiones <- 30
ensayo <- function(x)
  ifelse(sample(poblacion[["sexo"]], 1) == "Mujer", 1, 0)
treinta.repeticiones <- sapply(1:n.repeticiones, ensayo)

#Calculo frecuencias de 1
frecuencia_1 <- table(treinta.repeticiones)[names(table(treinta.repeticiones)) == 1]
#Calculo de la frecuencia
p <- frecuencia_1/n.repeticiones

#Calculo distribuci�n binomial
binomial = (factorial(n.repeticiones)/(factorial(treinta.repeticiones)*factorial(n.repeticiones- treinta.repeticiones)))*(p^treinta.repeticiones)*(1-p)^(n.repeticiones - treinta.repeticiones)


geometrica =  p*(1-p)^(treinta.repeticiones)

# Dist binomial negativa.
binomialN = c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)
test = for (i in frecuencia_1:n.repeticiones) {
  binomialN <- c(binomialN, choose(i-1, frecuencia_1-1) * (p^frecuencia_1) * (1-p)^(i-frecuencia_1))
}

# Normal
plot(density(ingreso.normal))

# Z
plot(density(z))

# chi
plot(density(c(chi_Cuadrado_seis, chi_Cuadrado_doce)))

# f
dist_f(f, deg.f1 = 6, deg.f2 = 12)

# Geometrica
plot(density(geometrica))

# Binomial
plot(density(binomial))

# Binomial negativa
plot(density(binomialN))







