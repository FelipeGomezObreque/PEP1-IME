# Sala 2
#   Joaquin Torres
#   Carlos Castillo
#   Francisco Moreno
#   Gianfranco Piccinini
# ¿Que variables se han cargado?
#   Variable region y variable fecha
# ¿Que tipo tiene cada una de estas variables?
#   Variable region: categorica nominal
#   Variable fecha: numerica discreta
# ¿Que escala parecen tener estas variables?
#   Variable region: escala nominal
#   Variable fecha: escala ordinal

library(dplyr)
library(tidyr)

# Cargar .csv a data frame
data <- read.csv(choose.files(), encoding="UTF-8")

# ¿Que dia se produjo el mayor numero de casos con sintomas en la region de 
# AYSEN entre el 01-MAR-2021 y el 31-AGO-2021?
data_aysen <- dplyr::filter(data, Region=="Aysén")
data_aysen <- dplyr::select(data_aysen, "X2021.03.01":"X2021.08.31")

variables <- names(data_aysen)
data_longer_aysen <- data_aysen %>% tidyr::pivot_longer ( variables,
                                                   names_to = "fechas",
                                                   values_to = "contagios")

obs_mayor_contagio <- data_longer_aysen %>% filter(contagios == max(data_longer_aysen[["contagios"]]))
print(obs_mayor_contagio)

# ¿Cual fue el total de casos con sintomas para cada mes de este periodo?
data_mes03 <- dplyr::select(data_aysen, starts_with("X2021.03"))
cat("Total de casos mes 03:\n")
print(sum(t(data_mes03)))
cat("\n")

data_mes04 <- dplyr::select(data_aysen, starts_with("X2021.04"))
cat("Total de casos mes 04:\n")
print(sum(t(data_mes04)))
cat("\n")

data_mes05 <- dplyr::select(data_aysen, starts_with("X2021.05"))
cat("Total de casos mes 05:\n")
print(sum(t(data_mes05)))
cat("\n")

data_mes06 <- dplyr::select(data_aysen, starts_with("X2021.06"))
cat("Total de casos mes 06:\n")
print(sum(t(data_mes06)))
cat("\n")

data_mes07 <- dplyr::select(data_aysen, starts_with("X2021.07"))
cat("Total de casos mes 07:\n")
print(sum(t(data_mes07)))
cat("\n")

data_mes08 <- dplyr::select(data_aysen, starts_with("X2021.08"))
cat("Total de casos mes 08:\n")
print(sum(t(data_mes08)))
cat("\n")