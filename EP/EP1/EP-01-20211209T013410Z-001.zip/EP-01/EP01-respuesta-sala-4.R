# Respuesta a las primeras 3 preguntas del pdf
# Las variables cargadas corresponden a los casos nuevos de COVID19 por dia en cada 
# region del pais, las fechas van del 03/03/2020 hasta el 23/09/2021, ademas pertenecen a 
# tipo numerico discreto porque solo toman cifras enteras y a una escala de razon, pues no 
# pueden tomar valores negativos ya que no tendrian ning�n sentido en la realidad, ademas 
# de iniciar en cero absoluto.
# Se importan las librerias a usar
library(dplyr)
library(tidyr)
# se busca el directorio en el que se esta trabajando
getwd()
# ocupar la funci�n setwd() en caso de ser necesario, o en su defecto mover el archivo al lugar de trabajo
# se lee el csv 
datos <- read.csv("CasosNuevosConSintomas.csv", stringsAsFactors = FALSE, encoding = "UTF-8")
# se obtiene solo la fila de Coquimbo, puesto que es la solicitada
datos <- datos[5,c(2:571)]

# se pasa a formato largo
datos <- datos %>% pivot_longer(c(1:570), names_to = "Fecha", values_to = "Casos")


inicio <- which(datos[,1] == "X2020.05.01")#indice de la fecha de inicio
fin <- which(datos[,1] == "X2020.10.31")#indice de la fecha de termino
# Se obtiene el maximo de datos
datos <- datos[c(inicio:fin),]
maximo <- max(datos[,2])

# Comienza la captura de total de contagiados con sintomas por mes
#mayo
inicio <- which(datos[,1] == "X2020.05.01")
termino <-  which(datos[,1] == "X2020.05.31")
mayo <- sum(datos[c(inicio:termino),2])

#junio
inicio <- which(datos[,1] == "X2020.06.01")
termino <-  which(datos[,1] == "X2020.06.30")
junio <- sum(datos[c(inicio:termino),2])

#julio
inicio <- which(datos[,1] == "X2020.07.01")
termino <-  which(datos[,1] == "X2020.07.31")
julio <- sum(datos[c(inicio:termino),2])

#agosto
inicio <- which(datos[,1] == "X2020.08.01")
termino <-  which(datos[,1] == "X2020.08.31")
agosto <- sum(datos[c(inicio:termino),2])

#septiembre
inicio <- which(datos[,1] == "X2020.09.01")
termino <-  which(datos[,1] == "X2020.09.30")
septiembre <- sum(datos[c(inicio:termino),2])

#octubre
inicio <- which(datos[,1] == "X2020.10.01")
termino <-  which(datos[,1] == "X2020.10.31")
octubre <- sum(datos[c(inicio:termino),2])
# Para finalizar se muestran los datos solicitados
print(paste("Mayor numero de casos entre mayo y octubre:", maximo))
print(paste("total de casos en mayo:", mayo))
print(paste("total de casos en junio:", junio))
print(paste("total de casos en julio:", julio))
print(paste("total de casos en agosto:", agosto))
print(paste("total de casos en septiembre:", septiembre))
print(paste("total de casos en octubre: ", octubre))






