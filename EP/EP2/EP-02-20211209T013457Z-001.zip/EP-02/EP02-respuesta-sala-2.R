#Librerias a utilizar
library(dplyr)
library (ggpubr)
library(ggplot2)

# Cargar archivo.csv como un data frame
data <- read.csv(choose.files(), encoding="UTF-8")

#PREGUNTA A DESARROLLAR:
#�C�mo dir�a que es el ingreso de los hombres de la RM (sim�trico/asim�trico, 
#concentrado/disperso, unimodal/multimodal, etc.)?

#Desarrollo:

#Se filtran todos los hombres de la Regi�n Metropolitana
hombre_rm <- data %>% filter(region == "Regi�n Metropolitana de Santiago" & sexo == "Hombre")

# Histograma mostrando la frecuencia de los ingresos totales en 100 intervalos, 
#utilizando la media para diferenciar simetr�a y su modalidad.
grafico1 <- gghistogram ( hombre_rm ,
                    x = "ytot",
                    bins = 100 ,
                    add = "mean",
                    xlab = "Ingresos totales",
                    ylab = "Frecuencia",
                    color = "black",
                    title = "Ingresos de los hombres en la RM",
                    fill = "blue")

#Se muestra el gr�fico histograma
print(grafico1)

#Se calcula el coeficiente de variabilidad para diferenciar la dispersi�n.
desv <- summarise(hombre_rm, cv = (sd(ytot)/mean(ytot)))
#Se muestra el resultado del coeficiente
print(desv)

#Se crea gr�fico boxplot para mostrar dispersi�n
ingresos_h_rm <- select(hombre_rm, ytot)
grafico2 <- ggplot(ingresos_h_rm, aes(y=ytot, x=0)) + 
  stat_boxplot(geom = "errorbar", width = 0.15) +
  geom_boxplot() +
  ggtitle("Diagrama de dispersi�n ingresos") +
  ylab("Ingresos") + 
  xlab("") +
  geom_jitter(width = 0.2)

#Se muestra el gr�fico boxplot
print(grafico2)

#Respuestas:

# Seg�n el gr�fico 1, siendo un histograma, se concluye que los ingresos de los
#hombres de la regi�n metropolitana tiene un comportamiento asim�trico negativo,
#en este caso, se utiliz� la media de cada intervalo (100 intervalos), para 
#poder concluir dicho comportamiento.

# Adem�s, se concluye que tiene un comportamiento unimodal, ya que solo presenta
#una unica moda de acuerdo a las frecuencias de grafico 1.

# Finalmente,al evaluar el resultado del coeficiente de variabilidad, da como
#resultado 1.936265, valor mayor a 1, equivalente a comportamiento disperso. 
#Se incluye grafico 2 boxplot: n�tese que una cantidad elevada de valores se
#encuentra fuera de la caja.