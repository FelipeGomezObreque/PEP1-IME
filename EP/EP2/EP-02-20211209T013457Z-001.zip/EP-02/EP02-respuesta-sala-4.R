library(dplyr)
library(tidyr)
library(ggpubr)
setwd("C:\\Users\\mauri-Pc\\Desktop\\Inferencia y modelos estadisticos\\clases ejercicios\\ejercicio 2")
datos <- read.csv("EP-02 Datos Casen 2017.csv", stringsAsFactors = FALSE, encoding = "UTF-8")

datos <- datos %>% filter(sexo == "Hombre")

#frecuencias 
tabla <- as.data.frame(xtabs(~ ch1 + zona, data = datos ))
freq <- as.data.frame(tabla)

#grafica
g1 <- ggplot ( freq , aes( fill = zona , y = Freq , x = ch1 ))
g1 <- g1 + geom_bar( position = "stack", stat = "identity")
g1 <- g1 + labs (y = "Frecuencia") + ggtitle ("Distribucion de poblacion")
g1 <- g1 + theme_pubr ()
g1 <- g1 + rotate_x_text(angle = 30)
print(g1)